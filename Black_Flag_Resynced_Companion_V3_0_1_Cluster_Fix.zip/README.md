# Black Flag Resynced Companion — Version 3.0.1

Version 3.0.1 moves the companion from one very large HTML file to a modular project while preserving the current interface and locally stored user data.

## Project structure

- `index.html` — application layout
- `styles.css` — core interface styling
- `touch-map.css` — touch-map and marker styling
- `animus.css` — Animus-inspired mobile design
- `version.js` — build/version metadata
- `database.js` — collectible and location records
- `app.js` — map, search, filters, editing, calibration and backup
- `planner.js` — dashboard and Jackdaw planner
- `interface.js` — bottom navigation, onboarding and update prompts
- `service-worker.js` — offline cache and update handling
- `manifest.webmanifest` — Home Screen installation settings

## Data compatibility

The app continues using the existing browser storage key, so progress, favorites, notes, corrections, calibration settings and planner status should remain available when this version replaces the prior one at the same GitHub Pages address.

Create a JSON backup before every major update as an extra precaution.

## Upload to GitHub

Upload every file in this ZIP to the root of the new repository. Keep the filenames unchanged.

Then enable GitHub Pages:

1. Open repository **Settings**.
2. Open **Pages**.
3. Select **Deploy from a branch**.
4. Choose `main` and `/ (root)`.
5. Save.

Open the published address in Safari once while online so the complete Version 3 app shell is cached.

## 3.0.1 upload

For this update, replace these files in the repository root:

- `app.js`
- `animus.css`
- `version.js`
- `service-worker.js`
- `manifest.webmanifest`
- `index.html`
- `CHANGELOG.md`

After GitHub Pages finishes deploying, close the installed app/Safari tab and reopen it. If the old map remains, refresh once in Safari so the new service worker takes control.
