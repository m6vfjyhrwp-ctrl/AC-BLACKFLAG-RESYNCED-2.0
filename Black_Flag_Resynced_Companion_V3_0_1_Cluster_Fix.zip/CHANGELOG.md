# Changelog

## 3.0.1 — Marker cluster fix

- Replaced fixed-grid grouping with zoom-aware screen-distance clustering.
- Markers now collapse back into fewer clusters when zooming out.
- Cluster taps always zoom farther instead of unexpectedly zooming out.
- Cluster centers now use the average position of their contained locations.
- At maximum zoom, tapping an unresolved cluster opens a location chooser.
- Added accessible labels and larger reliable touch behavior for clusters.

## 3.0.0 — Modular foundation

- Split the original standalone file into maintainable application modules.
- Preserved the touch-first map and Animus interface.
- Preserved the existing local-storage data format.
- Added an explicit app version module.
- Rebuilt the offline service worker around the modular app shell.
- Prepared the project for larger databases, marker clustering and future route-planning modules.
